
let hora=new Date().getHours();
let saludo;
if (hora<7) {
	saludo="\n Good night";
} else if (hora<13) {
	saludo="\n Good morning";
} else {
	saludo="\n Good afternoon";
}
console.log(`${saludo}, its ${hora} o\'clock`);

console.log();
console.log(Number(Math.PI.toFixed(6)));

console.log(`\n`);
let m=22;
let j=0;
function tabla_num (j) {
  console.log(j+' dec = '+(j).toString(16)+' hex = '+(j).toString(8)+' oct = '+(j).toString(2)+' bin');
}
while (j <= m) {
  tabla_num (j);
  j+=1;
}

console.log(`\n`);
let n=21;
let i=0;
function tabla_num_odd (i) {
  if ((i % 2) !== 0 && i < 10) {
          console.log(i+' dec = '+(i).toString(16)+' hex = '+(i).toString(8)+' oct = '+(i).toString(2)+' bin');
    } else if ((i % 2) !== 0 && i > 20) {
          console.log(i+' dec = '+(i).toString(16)+' hex = '+(i).toString(8)+' oct = '+(i).toString(2)+' bin');
    }
}
for (i = 0; i <= n; i++) {
  tabla_num_odd (i);
}

console.log(`\n`);
console.log(`\u55e8\uff0c\u4f60\u597d\u5417`);

console.log(`\n`);
console.log(`“The program has finished”`)